DRI Code Sessions - TDD

Run the tests with "phpunit TestPlayer.php"